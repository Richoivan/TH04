﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week4
{
    public partial class Form1 : Form
    {
        DataTable dt = new DataTable();
        List<string> countrylist = new List<string>();
        List<string> teamlist = new List<string>();
        List<string> teamlistpilih = new List<string>();
        string[] posisiorang = { "GK", "DF", "MF", "FW" };
        int Country = 0;
        int Team = 0;
        public Form1()
        {
            InitializeComponent();

            dt.Columns.Add("Country");
            dt.Columns.Add("City");
            dt.Columns.Add("Team");
            dt.Columns.Add("Playerss");
            dt.Columns.Add("Number");
            dt.Columns.Add("Position");

            dt.Rows.Add("England", "Manchester", "Manchester United", "David de Gea", "1", "GK");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Aaron Wan-Bissaka", "29", "DF");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Harry Maguire", "5", "DF");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Raphael Varane", "19", "DF");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Luke Shaw", "23", "DF");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Fred", "17", "MF");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Paul Pogba", "6", "MF");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Bruno Fernandes", "18", "MF");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Jadon Sancho", "7", "FW");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Cristiano Ronaldo", "27", "FW");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Marcus Rashford", "10", "FW");
            dt.Rows.Add("England", "Manchester", "Manchester United", "De Leo", "4", "FW");

            dt.Rows.Add("England", "Liverpool", "Liverpool", "Alisson Becker", "1", "GK");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Trent Alexander-Arnold", "66", "DF");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Virgil van Dijk", "4", "DF");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Joël Matip", "32", "DF");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Andrew Robertson", "26", "DF");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Fabinho", "3", "MF");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Jordan Henderson", "14", "MF");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Thiago Alcântara", "6", "MF");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Mohamed Salah", "11", "FW");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Sadio Mané", "10", "FW");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Roberto Firmino", "9", "FW");

            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Thibaut Courtois", "1", "GK");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Dani Carvajal", "2", "DF");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Éder Militão", "3", "DF");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Sergio Ramos", "4", "DF");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Ferland Mendy", "23", "DF");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Casemiro", "14", "MF");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Luka Modrić", "10", "MF");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Toni Kroos", "8", "MF");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Eden Hazard", "7", "FW");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Karim Benzema", "9", "FW");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Vinícius Júnior", "20", "FW");

            countrylist.Add("England");
            countrylist.Add("Spain");

            teamlist.Add("England=Manchester United");
            teamlist.Add("England=Liverpool");
            teamlist.Add("Spain=Real Madrid");

            for (int i = 0; i < countrylist.Count; i++)
            {
                comboBox1.Items.Add(countrylist[i]);
            }
        }

        private void GantiList()
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {

            }
        }

        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            comboBox2.Items.Clear();
            teamlistpilih.Clear();
            for (int i = 0; i < teamlist.Count; i++)
            {
                if (teamlist[i].Contains(countrylist[comboBox1.SelectedIndex] + "="))
                {
                    string[] namateam = teamlist[i].Split('=');
                    comboBox2.Items.Add(namateam[1]);

                    teamlistpilih.Add(namateam[1]);
                }
            }

        }

        private void comboBox2_SelectionChangeCommitted(object sender, EventArgs e)
        {
            
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (comboBox2.Text == dt.Rows[i][2].ToString())
                {
                    listBox1.Items.Add("("+dt.Rows[i][4].ToString() + ") "+dt.Rows[i][3].ToString()+","+ dt.Rows[i][5].ToString());
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bool adanegara = false;
            bool adateam = false;

            for (int i = 0;i < countrylist.Count; i++)
            {
                if (textBox1.Text == countrylist[i])
                {
                    adanegara = true;
                }
            }

            for (int i = 0;i < teamlist.Count; i++)
            {
                if (textBox2.Text == teamlist[i])
                {
                    adateam = true;
                }
            }


            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                if (adateam)
                {
                    MessageBox.Show("Team already available");
                }
                else
                {
                    teamlist.Add(textBox1.Text + "=" + textBox2.Text);
                    if (adanegara)
                    {

                    }
                    else
                    {
                        countrylist.Add(textBox1.Text);
                    }
                    comboBox1.Items.Clear();
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";

                    for (int i = 0; i < countrylist.Count; i++)
                    {
                        comboBox1.Items.Add(countrylist[i]);
                    }
                }
            }
            else
            {
                MessageBox.Show("Error, please fill the rest");
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nama = listBox1.SelectedItem.ToString();
            bool sebelasorang = false;

            string team = teamlistpilih[comboBox2.SelectedIndex];

            int hitung = 0;
            for (int i = 0;i < dt.Rows.Count; i++)
            {
                if (team == dt.Rows[i][2].ToString())
                {
                    hitung++;
                }
            }

            if (hitung <= 11)
            {
                sebelasorang = true;
            }

            if (sebelasorang)
            {
                MessageBox.Show("Cannot be below 11 players");
            }
            else
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (nama.Contains(dt.Rows[i][3].ToString()))
                    {
                        dt.Rows[i].Delete();
                    }
                }

                listBox1.Items.Clear();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (comboBox2.Text == dt.Rows[i][2].ToString())
                    {
                        listBox1.Items.Add("(" + dt.Rows[i][4].ToString() + ") " + dt.Rows[i][3].ToString() + "," + dt.Rows[i][5].ToString());
                    }
                }
            }

            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string nama = textBox4.Text;
            string nomer = textBox5.Text;
            string posisi = posisiorang[comboBox3.SelectedIndex];

            if (nama != "" && nomer != "" && comboBox3.SelectedIndex != -1)
            {

                if (comboBox1.SelectedIndex != -1 && comboBox2.SelectedIndex != -1)
                {
                    dt.Rows.Add(countrylist[comboBox1.SelectedIndex], teamlistpilih[comboBox2.SelectedIndex], teamlistpilih[comboBox2.SelectedIndex], nama, nomer, posisi);

                }

                textBox4.Text = "";
                textBox5.Text = "";
                comboBox3.SelectedIndex = -1;

                listBox1.Items.Clear();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (comboBox2.Text == dt.Rows[i][2].ToString())
                    {
                        listBox1.Items.Add("(" + dt.Rows[i][4].ToString() + ") " + dt.Rows[i][3].ToString() + "," + dt.Rows[i][5].ToString());
                    }
                }
            }
            else
            {
                MessageBox.Show("Error, please fill the rest");
            }
        }
    }
}
